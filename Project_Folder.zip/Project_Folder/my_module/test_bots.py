import itertools
import random
import string
import pytest
from Last_Man_Standing import TeleportBot
from Last_Man_Standing import WanderBot
from Last_Man_Standing import ExploreBot
from Last_Man_Standing import play_board

from time import sleep
from IPython.display import clear_output

def test_bots():
           
    bots = [TeleportBot(), WanderBot(), ExploreBot()]
    obstacles = 6
    
    assert TeleportBot()
    assert WanderBot()
    assert ExploreBot()
    play_board(bots, obstacles)
    
